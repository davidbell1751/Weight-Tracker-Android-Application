package com.zybooks.weighttracker;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class WeightUpdate extends AppCompatActivity {

    WeightDatabase myDb;
    EditText editName, editStartInput, editGoalInput, editTextId;
    Button btnAddData;
    Button btnviewAll;
    Button btnDelete;

    Button btnviewUpdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_update);
        myDb = new WeightDatabase(this);

        editName = (EditText)findViewById(R.id.editTextName);
        editStartInput = (EditText)findViewById(R.id.editTextStartInput);
        editGoalInput = (EditText)findViewById(R.id.editTextGoalInput);
        editTextId = (EditText)findViewById(R.id.editText_id);
        btnAddData = (Button)findViewById(R.id.button_add);
        btnviewAll = (Button)findViewById(R.id.button_view);
        btnviewUpdate = (Button)findViewById(R.id.button_update);
        btnDelete = (Button)findViewById(R.id.button_delete);
        AddData();
        viewAll();
        UpdateData();
        DeleteData();

    }

    public void DeleteData(){
        btnDelete.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                         Integer deletedRows = myDb.deleteData(editTextId.getText().toString());                                       // call delete data function   // needs one argument
                        if(deletedRows > 0)
                                Toast.makeText(WeightUpdate.this, "Data Deleted", Toast.LENGTH_LONG).show();
                            else
                                Toast.makeText(WeightUpdate.this, "Data not Deleted", Toast.LENGTH_LONG).show();
                    }
                }
        );

    }

    public void UpdateData(){               // button to update data
        btnviewUpdate.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        boolean isUpdate = myDb.updateData(editTextId.getText().toString(),                     // call update data function
                                editName.getText().toString(),                                                  // pass data from the edit text inputs
                                editStartInput.getText().toString(),
                                editGoalInput.getText().toString());                                              // use boolean to check if the data is updated
                        if(isUpdate == true) {
                            //show message
                            if(isUpdate == true)
                                Toast.makeText(WeightUpdate.this, "Data Updated", Toast.LENGTH_LONG).show();
                            else
                                Toast.makeText(WeightUpdate.this, "Data not Updated", Toast.LENGTH_LONG).show();

                        }
                    }
                }
        );
    }

    public void AddData() {
        btnAddData.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        boolean isInserted = myDb.insertData(editName.getText().toString(),     // return true if data is inserted using boolean isInserted
                                editStartInput.getText().toString(),
                                editGoalInput.getText().toString()        );
                        if(isInserted == true)
                            Toast.makeText(WeightUpdate.this, "Data Inserted", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(WeightUpdate.this, "NO Readable Data", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    public void viewAll() {
        btnviewAll.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Cursor res = myDb.getAllData();
                        if (res.getCount() == 0) {            // 0 means no data available when we query the database
                            // show message
                            showMessage("Error", "No data found");
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {          // moves cursor to next result
                            buffer.append("Id : " + res.getString(0) + "\n");          // index of the column starts at 0    0 = Id  1 = Name Etc.
                            buffer.append("Name : " + res.getString(1) + "\n");
                            buffer.append("Startweight : " + res.getString(2) + "\n");
                            buffer.append("Goalweight : " + res.getString(3) + "\n\n");           // double line break to last column
                        }
                        // Show all data
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String title, String Message) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(true);
            builder.setTitle(title);
            builder.setMessage(Message);
            builder.show();
        }
}