package com.zybooks.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class databaseDisplay extends AppCompatActivity {



    private TextView removed;
    private TextView toGo;
    private EditText firstWeight;
    private EditText updateCurrentWeight;
    private EditText startweight;
    private EditText goalweight;
    private TextView currentWeight;
    private TextView percentToGo;
    Button database;

    //textViewRemovedNumber
            //textViewToGo

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_display);


        removed = (TextView)findViewById(R.id.textViewRemovedNumber);
        toGo = (TextView)findViewById(R.id.textViewToGo);
        firstWeight = (EditText)findViewById(R.id.editTextStartWeight);
        updateCurrentWeight = (EditText)findViewById(R.id.editTextUpdateCurrentWeight);
        startweight = (EditText)findViewById(R.id.editTextStartWeight);
        goalweight = (EditText)findViewById(R.id.editTextGoal);
        currentWeight = (TextView)findViewById(R.id.textViewCurrentWeight);
        percentToGo = (TextView)findViewById(R.id.textViewPercentToGo);
        database = (Button)findViewById(R.id.button_sqlDatabase);

    //final EditText updateCurrentWeight = (EditText)findViewById(R.id.editTextUpdateCurrentWeight);
    //final TextView currentWeight = (TextView) findViewById(R.id.textViewCurrentWeight);
    Button updateWeight = (Button)findViewById(R.id.buttonUpdate);
    Button database = (Button)findViewById(R.id.button_sqlDatabase);

    database.setOnClickListener(
            new View.OnClickListener() {                                // button to move to the sql database screen
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(databaseDisplay.this, WeightUpdate.class);
                    startActivity(intent);

                }
            }
    );


    updateWeight.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            String number = updateCurrentWeight.getText().toString();  // this will get the text that is entered into the update current weight box and place it in the current weight update at the top

            currentWeight.setText(number);

            int number1 = Integer.parseInt(updateCurrentWeight.getText().toString());
            int number2 = Integer.parseInt(firstWeight.getText().toString());
            int number3 = Integer.parseInt(removed.getText().toString());
            int number4 = Integer.parseInt(toGo.getText().toString());
            int number5 = Integer.parseInt(goalweight.toString());
            int number6 = Integer.parseInt(startweight.toString());
            int number7 = Integer.parseInt(currentWeight.toString());
            int number8 = Integer.parseInt(percentToGo.toString());
            int sum1 = number2 - number1;       //this will give us the weight that the user has removed
            int sum2 = number7 - number6;       // this will give the user the weight they have left to go until they reach their goal weight
            int sum3 = (number4*100)/number2;   // this will calculate the percentage of weight they have left to go
            toGo.setText(String.valueOf(sum2));     // this will place the sum from the equation into the textview box textViewToGO
            removed.setText(String.valueOf(sum1));      // this will place the sum from the equation into the textView box textViewRemoved
            percentToGo.setText(String.valueOf(sum3));  // this will place the sum from the equation into the percentToGo textview box



        }
    });





    }


    }
